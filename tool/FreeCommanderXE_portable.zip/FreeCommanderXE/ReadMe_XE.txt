================================================================================
WHAT IS FreeCommander
================================================================================
FreeCommander is an easy-to-use alternative to the standard Windows file manager. 
You can configure almost everything. Supported Windows versions: Windows XP and above.
The actual version of FreeCommander XE is a 32 bit program. 
Please check the info about using FreeCommander XE on 64 bit Windows http://freecommander.com/fc_logchanges_en.htm.    



================================================================================
AFTER YOU HAVE INSTALLED FreeCommander XE
================================================================================

If you have worked with the FreeCommander 2009.02b:
- the settings of the FreeCommander 2009.02b are not compatible with the settings of the FreeCommander XE
- do not copy the old settings to the new settings folder

If you have used FreeCommander XE before 601 release:
- the favorite folders of the releases before 601 are not compatible with favorite folders from release 601 and above
- in that case you must define your favorite folders again


Currently are available help files for the languages: German and Spanish http://freecommander.com/fc_languages.htm. 
The english help file for the version XE does not exist yet but you can download (http://freecommander.com/fc_languages.htm) 
the english help file from the version 2009.02b - many functions are similar.   
Additionally, you can check the FreeCommander Guide http://www.freecommander.com/fc_guide_en.htm, which helps you getting started.


Trouble with the help file
==========================
When viewing your CHM documentation, Microsoft's HTML Help Viewer is showing an error page saying either that:
 - The action has been canceled 
 - The page cannot be displayed
 
Solutions
 - Launch help file from local drive and not from a network path or via a mapped networked drive.  
 - Make sure your help file isn't in a path with symbols such as "#" (sharp).  
 - In some cases, you can have access to an "unblock" button in the properties page of the help file. Right click on the file then go to its properties and click the "unblock" button. This button is not available in all systems though. 
 - Try the HHReg utility http://www.ec-software.com/products_hhreg.html or read this technical note from the Microsoft Knowledge Base http://support.microsoft.com/kb/896054/.

================================================================================
FEEDBACK & SUGGESTIONS
================================================================================

Direct your feedback, suggestions and bug reports to the FreeCommander forum http://www.forum.freecommander.com
or directly to me marek@freecommander.com but please do not expect that you get an answer immediately :). 


I hope you will enjoy FreeCommander 

MAREK JASINSKI





